package de.uni_hamburg.informatik.swt.se2.mediathek.materialien;

import java.util.ArrayList;
import java.util.List;


import de.uni_hamburg.informatik.swt.se2.mediathek.materialien.medien.Medium;

public class Vormerkkarte {

	

    // Eigenschaften einer Vormerkkarte (wieso ist die Liste final gewesen?)
    private List<Kunde> _kunden;
    private final Medium _medium;
    
    public Vormerkkarte(Medium medium)
    {
    	_kunden = new ArrayList<Kunde>();
    	_medium = medium;
    }
    
    //Gibt die Liste der Kunden auf der Vormerkkarte zurueck
    public List<Kunde> getKunden()
    {
    	return _kunden;
    }
    
    /**
     * Gibt Kunde auf der Vormerkkarte auf einer bestimmten Position zurueck
     * @param position
     * @return
     */
    public Kunde getKunde(int position)
    {
    	return _kunden.get(position);
    }
    
  //Gibt das Medium der Kunden auf der Vormerkkarte zurueck
    public Medium getMedium()
    {
    	return _medium;
    }
    
    /**
     * Fügt einen Kunden zur Liste hinzu
     * 
     * @param kunde
     */
    public void fuegeKundeHinzu(Kunde kunde) 
    {
    	if(kannVorgemerktWerden(kunde))
    	{
    		_kunden.add(kunde);
    	}
    }
    
    /**
     * entfernt einen Kunden von der Liste
     * 
     * @param kunde
     */
    public void entferneKunde(Kunde kunde) 
    {
    	_kunden.remove(kunde);
    }
    
    /**
     * Prüft ob Kunde bereits in Vormerk Liste ist
     * oder ob Liste bereits voll ist (size == 3)
     * 
     * @param kunde
     * @return
     */
    public boolean kannVorgemerktWerden(Kunde kunde) 
    {
    	boolean booleanWert = false;
    	if (_kunden.size() < 3 && !_kunden.contains(kunde)) 
    	{
    		booleanWert = true;
    	}
    	return booleanWert;
    }
    
    
}
