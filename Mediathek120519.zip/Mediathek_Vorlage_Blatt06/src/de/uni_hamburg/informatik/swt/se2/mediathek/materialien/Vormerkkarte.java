package de.uni_hamburg.informatik.swt.se2.mediathek.materialien;

import java.util.List;

import de.uni_hamburg.informatik.swt.se2.mediathek.fachwerte.Datum;
import de.uni_hamburg.informatik.swt.se2.mediathek.materialien.medien.Medium;

public class Vormerkkarte {

	

    // Eigenschaften einer Vormerkkarte
    private final List<Kunde> _kunden;
    private final Medium _medium;
    
    public Vormerkkarte(List<Kunde> kunden, Medium medium){
    	_kunden = kunden;
    	_medium = medium;
    }
    
    //Gibt die Liste der Kunden auf der Vormerkkarte zurueck
    public List<Kunde> getKunden(){
    	return _kunden;
    }
    
    public Medium getMedium(){
    	return _medium;
    }
    
    public void fuegeKundeHinzu(Kunde kunde) {
    	if(kannVorgemerktWerden(kunde)) {
    		_kunden.add(kunde);
    	}
    }
    
    public void entferneKunde(Kunde kunde) {
    	_kunden.remove(kunde);
    }
    
    /**
     * Prüft ob Kunde bereits in Vormerk Liste
     * oder ob Liste bereits voll (size == 3)
     * 
     * @param kunde
     * @return
     */
    public boolean kannVorgemerktWerden(Kunde kunde) {
    	boolean booleanWert = false;
    	if (_kunden.size() < 3 && !_kunden.contains(kunde)) {
    		booleanWert = true;
    	}
    	return booleanWert;
    }
}
