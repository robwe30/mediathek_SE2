package de.uni_hamburg.informatik.swt.se2.mediathek.materialien;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
//import static org.junit.Assert.assertNotNull;
//import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

//import de.uni_hamburg.informatik.swt.se2.mediathek.fachwerte.Datum;
//import de.uni_hamburg.informatik.swt.se2.mediathek.fachwerte.Geldbetrag;
import de.uni_hamburg.informatik.swt.se2.mediathek.fachwerte.Kundennummer;
import de.uni_hamburg.informatik.swt.se2.mediathek.materialien.medien.CD;
import de.uni_hamburg.informatik.swt.se2.mediathek.materialien.medien.Medium;

public class VormerkkarteTest
{
    private List<Kunde> _kunden;    
    private Kunde _kunde;
    
    private Medium _medium;
    private Vormerkkarte _karte;
    
    
    //Konstruktor
    public VormerkkarteTest()
    {
    	_kunden = new ArrayList<Kunde>();
    	_kunde = new Kunde(new Kundennummer(123456), "ich", "du");

    
    	
        _medium = new CD("bar", "baz", "foo", 123);
        _karte = new Vormerkkarte(_medium);
    }
//TESTS
    
    @Test
    public void testeKonstruktor() throws Exception
    {
        assertEquals(_kunden, _karte.getKunden());        
    	assertEquals(_medium, _karte.getMedium());

    }

    @Test
    public void testeFuegeKundeHinzu() 
    {
       Vormerkkarte karte1 = new Vormerkkarte (_medium);
       karte1.fuegeKundeHinzu(_kunde);
       
       _kunden.add(_kunde);
      	
    	
    	
    	assertEquals(_kunden, karte1.getKunden());        


    }
    
    @Test
    public void testeGetKunde()
    {
   
    	Vormerkkarte karte1 = new Vormerkkarte (_medium);
      karte1.fuegeKundeHinzu(_kunde);	
    	    	
   
		assertEquals(_kunde, karte1.getKunde(0));        


    }   
    
    
    @Test
    public void testeEntferneKunde()
    {
   
    	Vormerkkarte karte1 = new Vormerkkarte (_medium);
      karte1.fuegeKundeHinzu(_kunde);
      karte1.entferneKunde(_kunde);
      
    	    	
   
		assertEquals(_kunden, karte1.getKunden());        


    }   
    
    @Test
    public void testeGetKunden()
    {
   
    	Vormerkkarte karte1 = new Vormerkkarte (_medium);
		  
		assertEquals(_kunden, karte1.getKunden());        


    } 
    
    
    
    @Test
    public void testeGetMedium()
    {
   
    	Vormerkkarte karte1 = new Vormerkkarte (_medium);
		  
		assertEquals(_medium, karte1.getMedium());        


    } 
    
    
    
    @Test
    public void testeKannVorgemerktWerden()
    {
   
    	Vormerkkarte karte1 = new Vormerkkarte (_medium);		    	
    	Kunde kunde2 = new Kunde(new Kundennummer(654321), "ich", "du");
    	karte1.fuegeKundeHinzu(kunde2);
    	
    	assertTrue(karte1.kannVorgemerktWerden(_kunde));
    	assertFalse(karte1.kannVorgemerktWerden(kunde2));
    	

    } 
    
    
  
    
    

    
    
    
    

}
